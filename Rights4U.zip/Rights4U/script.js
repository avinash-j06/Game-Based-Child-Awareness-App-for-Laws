document.querySelector("#safetyRights").addEventListener("click", () => {
    window.location.href = "safety.html"; // Redirects to the page
});